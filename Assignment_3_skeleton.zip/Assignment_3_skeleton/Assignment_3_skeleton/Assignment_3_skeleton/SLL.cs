﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_3_skeleton
{
    public class Node
    {
        public object Data { get; set; }
        public Node Next { get; set; }
        public Node(object data)
        {
            Data = data;
            Next = null;
        }
    }
    public class SLL : ILinkedListADT
    {
        public int Count { get; set; }
        private Node head;
        public SLL()
        {
            head = null;
        }
        public bool IsEmpty()
        {
            if (head == null)
            {
                return true;
            }
            return false;
        }
        public void Clear()
        {
            head = null;
        }
        public void Append(object data)
        {
            Node newNode = new Node(data);
            if (head == null)
            {
                head = newNode;
                Count++;
            }
            else
            {
                Node currentNode = head;
                while (currentNode.Next != null)
                {
                    currentNode = currentNode.Next;
                }
                currentNode.Next = newNode;
                Count++;
            }
        }
        public void Prepend(object data)
        {
            Node newNode = new Node(data);
            newNode.Next = head;
            head = newNode;
            Count++;
        }
        public void Insert(object data, int index)
        {
            Node newNode = new Node(data);
            if (index < 0 || index > Count)
            {
                throw new IndexOutOfRangeException("Index is out of range");
            }
            if (index == 0)
            {
                newNode.Next = head;
                head = newNode;
                Count++;
            }
            Node previousNode = null;
            Node currentNode = head;
            for (int i = 0; i < index; i++)
            {
                previousNode = currentNode;
                currentNode = currentNode.Next;
            }
            previousNode.Next = newNode;
            newNode.Next = currentNode;
            Count++;
        }
        public void Replace(object data, int index)
        {

            if (index < 0 || index >= Count)
            {
                throw new IndexOutOfRangeException("The index is out of range");
            }
            if (index == 0)
            {
                head.Data = data;
            }

            Node currentNode = head;
            for (int i = 0; i < index; i++)
            {
                currentNode = currentNode.Next;
            }
            currentNode.Data = data;


        }
        public int Size()
        {
            return Count;
        }
        public void Delete(int index)
        {
            if (index < 0 || index >= Count)
            {
                throw new IndexOutOfRangeException("The index is out of range");
            }
            if (index == 0)
            {
                head = head.Next;
                Count--;
            }
            Node currentNode = head;
            Node previousNode = null;
            for (int i = 0; i < index; i++)
            {
                previousNode = currentNode;
                currentNode = currentNode.Next;
            }
            previousNode.Next = currentNode.Next;
            Count--;
        }
        public Object Retrieve(int index)
        {
            if (index < 0 || index >= Count)
            {
                throw new IndexOutOfRangeException("The index is out of range");
            }
            if (index == 0)
            {
                return head.Data;

            }
            Node currentNode = head;
            for (int i = 0; i < index; i++)
            {
                currentNode = currentNode.Next;
            }
            return currentNode.Data;
        }
        public int IndexOf(object data)
        {
            Node node = new Node(data);
            if (node == null)
            {
                throw new ArgumentNullException(nameof(node), "The node cannot be null");
            }
            if (head.Data.Equals(node.Data))
            {
                return 0;
            }
            Node currentNode = head;
            int index = 0;
            while (currentNode != null)
            {
                if (currentNode.Data.Equals(node.Data))
                {
                    return index;
                }
                currentNode = currentNode.Next;
                index++;
            }
            return index;
        }
        public bool Contains(object Data)
        {
            Node node = new Node(Data);
            Node currentNode = head;
            while (currentNode != null)
            {
                if (currentNode.Data.Equals(node.Data))
                {
                    return true;
                }
                currentNode = currentNode.Next;
            }
            return false;
        }
        public void Reverse()
        {
            if (head == null)
            {
                return;
            }
            Node currentNode = head;
            Node previousNode = null;
            Node nextNode = null;
            while (currentNode != null)
            {
                nextNode = currentNode.Next;
                currentNode.Next = previousNode;
                previousNode = currentNode;
                currentNode = nextNode;
            }
            head = previousNode;
        }
    }
}

