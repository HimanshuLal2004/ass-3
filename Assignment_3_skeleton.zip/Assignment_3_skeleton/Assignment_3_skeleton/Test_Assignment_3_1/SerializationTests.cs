﻿using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace Assignment_3
{
    public class SerializationTests
    {
        private List<User> users;
        private readonly string testFileName = @"..\..\test_users.bin";

        [SetUp]
        public void Setup()
        {
            users = new List<User>
            {
                new User(1, "mike kishan", "mikekishan@gmail.com", "password"),
                new User(2, "rnaveer singh", "ranveersingh@outlook.com", "abcdef"),
                new User(3, "mukul", "chicken1890@gmail.com", "kfc5555"),
                new User(4, "Ronaldo", "4life63@outlook.com", "mcdonalds999")
            };
        }

        [TearDown]
        public void TearDown()
        {
            users.Clear();
        }

        // Tests the object was serialized.
        [Test]
        public void TestSerialization()
        {
            SerializationHelper.SerializeUsers(users, testFileName);
            Assert.IsTrue(File.Exists(testFileName));
        }

        [Test]
        public void TestDeSerialization()
        {
            SerializationHelper.SerializeUsers(users, testFileName);
            List<User> deserializedUsers = (List<User>)SerializationHelper.DeserializeUsers(testFileName);
            Assert.AreEqual(users.Count, deserializedUsers.Count);
            for (int i = 0; i < users.Count; i++)
            {
                Assert.AreEqual(users[i].Id, deserializedUsers[i].Id);
                Assert.AreEqual(users[i].Name, deserializedUsers[i].Name);
                Assert.AreEqual(users[i].Email, deserializedUsers[i].Email);
                Assert.AreEqual(users[i].Password, deserializedUsers[i].Password);
            }
        }
    }

    public class LinkedListTests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void IsEmptyTest()
        {
            LinkedList<string> linkedList = new LinkedList<string>();
            Assert.That(linkedList.IsEmpty(), Is.True);
        }

        [Test]
        public void AppendTest()
        {
            LinkedList<string> linkedList = new LinkedList<string>();
            linkedList.Append("mukul sharma");
            Assert.That(linkedList.Retrieve(0), Is.EqualTo("mukul sharma"));
        }

        [Test]
        public void PrependTest()
        {
            LinkedList<string> linkedList = new LinkedList<string>();
            linkedList.Prepend("mukul sharma");
            linkedList.Prepend("udhav");
            Assert.That(linkedList.Retrieve(1), Is.EqualTo("mukul sharma"));
        }

        [Test]
        public void InsertTest()
        {
            LinkedList<string> linkedList = new LinkedList<string>();
            linkedList.Append("mukul sharma");
            linkedList.Prepend("udhav");
            linkedList.Insert("himanshu", 2);
            Assert.That(linkedList.Retrieve(2), Is.EqualTo("himanshu"));
        }

        [Test]
        public void ReplaceTest()
        {
            LinkedList<string> linkedList = new LinkedList<string>();
            linkedList.Append("mukul sharma");
            linkedList.Prepend("udhav");
            linkedList.Replace("himanshu", 1);
            Assert.That(linkedList.Retrieve(1), Is.EqualTo("himanshu"));
        }

        [Test]
        public void SizeTest()
        {
            LinkedList<string> linkedList = new LinkedList<string>();
            linkedList.Append("himanshu");
            linkedList.Prepend("mukul sharma");
            linkedList.Prepend("udhav");
            Assert.That(linkedList.Size(), Is.EqualTo(3));
        }

        [Test]
        public void DeleteTest()
        {
            LinkedList<string> linkedList = new LinkedList<string>();
            linkedList.Append("himanshu");
            linkedList.Append("mike");
            linkedList.Prepend("mukul sharma");
            linkedList.Delete(1);
            Assert.That(linkedList.Contains("himanshu"), Is.False);
        }

        [Test]
        public void RetrieveTest()
        {
            LinkedList<string> linkedList = new LinkedList<string>();
            linkedList.Prepend("himanshu");
            linkedList.Append("mukul sharma");
            linkedList.Prepend("mike");
            Assert.That(linkedList.Retrieve(0), Is.EqualTo("mike"));
        }

        [Test]
        public void IndexOfTest()
        {
            LinkedList<string> linkedList = new LinkedList<string>();
            linkedList.Append("himanshu");
            linkedList.Append("mukul sharma");
            linkedList.Prepend("ranveer singh Singh");
            linkedList.Append("tom cruise");
            Assert.That(linkedList.IndexOf("mukul sharma"), Is.EqualTo(2));
        }

        [Test]
        public void ContainsTest()
        {
            LinkedList<string> linkedList = new LinkedList<string>();
            linkedList.Append("himanshu");
            linkedList.Append("mukul sharma");
            Assert.That(linkedList.Contains("himanshu"), Is.True);
        }

        [Test]
        public void ReverseTest()
        {
            LinkedList<string> linkedList = new LinkedList<string>();
            linkedList.Append("himanshu");
            linkedList.Append("mukul sharma");
            linkedList.Append("mike");
            linkedList.Append("tom cruise");
            linkedList.Reverse();
            Assert.That(linkedList.Retrieve(0), Is.EqualTo("tom cruise"));
        }
    }
}
